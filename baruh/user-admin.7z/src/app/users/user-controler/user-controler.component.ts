import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-user-controler',
  templateUrl: './user-controler.component.html',
  styleUrls: ['./user-controler.component.css']
})
export class UserControlerComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
