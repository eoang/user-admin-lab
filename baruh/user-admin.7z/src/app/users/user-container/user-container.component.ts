import { Component, OnInit } from '@angular/core';
import {UserInfo, UserModel} from '../../models/users.model';
import { calcPossibleSecurityContexts } from '@angular/compiler/src/template_parser/binding_parser';

@Component({
  selector: 'app-user-container',
  templateUrl: './user-container.component.html',
  styleUrls: ['./user-container.component.css']
})
export class UserContainerComponent implements OnInit{

   currentUser: UserModel ;
  constructor() {

    this.currentUser;
  }

  updateUser(username: string, email: string,jobName:string){
    this.currentUser.email = email;
    this.currentUser.username = username;
    this.currentUser.info.jobTitle=jobName;
  }

  ngOnInit() {
    console.log('User Container Init');
    this.currentUser = new UserModel(0, 'johndoe', 'johndoe@gmail.com',
      new UserInfo('John', 'Doe', 'Clerk', 'http://authenticgoods.co/wrapbootstrap/themes/sparks/img/team/avatar-male.png'));

  }
}
